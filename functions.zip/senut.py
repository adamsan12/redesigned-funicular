# main_async_single_optimized.py
import subprocess
import sys
import logging
import random
import re
import asyncio
import aiohttp
import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import List, Dict
# ============================================================================
# AUTO INSTALL DEPENDENCIES + UVLOOP
# ============================================================================
def install_dependencies():
    required = ['aiohttp']
    print("🔍 Memeriksa dependensi...")
    missing = [pkg for pkg in required if pkg not in sys.modules]
  
    if missing:
        print(f"⚠️ Menginstal: {', '.join(missing)}")
        for pkg in missing:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "--quiet"])
                print(f" ✅ {pkg} terinstal")
            except Exception:
                print(f" ❌ Gagal install {pkg}")
                sys.exit(1)
        print("🎉 Dependensi siap!\n")
# Aktifkan uvloop untuk performa lebih tinggi (sangat direkomendasikan)
try:
    import uvloop
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
    UVLOOP_ENABLED = True
except ImportError:
    UVLOOP_ENABLED = False
if __name__ == "__main__":
    install_dependencies()
# ============================================================================
# LOGGING
# ============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)
# ============================================================================
# ROTASI USER-AGENT (16 User-Agent Realistis)
# ============================================================================
USER_AGENTS = [
    # Chrome Windows
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
    # Chrome macOS
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    # Firefox
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:124.0) Gecko/20100101 Firefox/124.0',
    # Safari macOS
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
    # Edge
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',
    # Linux
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
]
def get_random_user_agent() -> str:
    """Mengembalikan User-Agent secara acak"""
    return random.choice(USER_AGENTS)
# ============================================================================
# CONFIGURATION
# ============================================================================
SHARD_BATCH_SIZE = 200
CONFIGS = {
    'doodstream': {
        'api_url': 'https://doodapi.com/api/file/list',
        'api_key': '112623ifbcbltzajwjrpjx',
        'per_page': 200,
        'request_delay': 0.35,
        'max_retries': 5,
        'concurrent_requests': 15,
        'timeout': 50,
    },
    'lulustream': {
        'api_url': 'https://api.lulustream.com/api/file/list',
        'api_key': '37943j35tc5i1bg3gcje5y',
        'per_page': 500,
        'request_delay': 0.35,
        'max_retries': 5,
        'concurrent_requests': 12,
        'timeout': 50,
    }
}
RANDOM_WORDS = [
    'Bokep Ngewe', 'Video Viral', 'Video Wiki', 'Video Yandex','Videy Link', 'Doodstream Link', 'Xpanas', 'SeBokep Viral', 'Playbokep Terbaru', 'Bokep Terlengkap', 'Drbokep', 'King Bokep', 'Bokep TikTok', 'Asupan Viral', 'Bebasindo', 'Bokepsin', 'Bokep Bispak', 'XPanas', 'Bokepindoh', 'INDO18', 'AVTUB', 'Bokep Dood', 'Bokep Video', 'Bokep31', 'Bokepind', 'Bokepindo', 'Bokepin',
    'Bokepsatset', 'Bokepsin', 'Video Yandex', 'Dodstream', 'Dood Viral', 'DoodTele', 'Yandex Viral', 'bokepsatset', 'bebasindo', 'doodstream', 'Doods Pro', 'Doodsflix', 'Doodstream', 'Doodstreem', 'Full Album', 'Link Asupan', 'Bokepindoh', 'Links Tele',
    'Lulustream', 'Memeksiana', 'Pejuang Lendir', 'Pekoblive', 'Pemersatu', 'Poophd', 'Popstream',
    'Simintok', 'King Bokep', 'Telegram', 'Terupdate', 'Tiktok', 'Toket Bagus', 'Twitter Viral',
    'Video Bokep', 'Video Indo', 'Video Lokal', 'Video Simontok', 'Video Sotwe', 'Video Terabox',
    'Yakwad'
]
WORD_REPLACEMENTS = {
    'bocil': 'cilbo',
    'sd': 'esdeh',
    'anak kecil': 'abg simontok',
    ' bocil ': ' cilbo ',
    ' sd ': ' esdeh ',
}
STOP_WORDS = {
    'di', 'ke', 'dari', 'pada', 'yang', 'untuk', 'dan', 'atau', 'tapi', 'tetapi',
    'dengan', 'oleh', 'karena', 'sehingga', 'agar', 'supaya', 'jika', 'kalau',
    'apabila', 'walau', 'meski', 'walaupun', 'meskipun', 'sementara', 'sedang',
    'ketika', 'saat', 'setelah', 'sebelum', 'hingga', 'sampai', 'demi', 'lewat',
    'melalui', 'via', 'tanpa', 'sejak', 'selama', 'sambil', 'seraya', 'biar',
    'atas', 'bawah', 'depan', 'belakang', 'samping', 'dalam', 'luar', 'antara',
    'sekitar', 'sebelah', 'hadap', 'tepi', 'pinggir', 'ujung', 'kah', 'lah',
    'tah', 'pun', 'nya', 'se', 'ber', 'ter', 'me', 'pe', 'per', 'mem', 'pen',
    'peng', 'men', 'pem', 'pel', 'meng', 'meny', 'memper', 'mempert', 'diper',
    'terper', 'kan', 'an', 'i', 'ku', 'mu', 'ini', 'itu', 'sini', 'situ', 'sana',
    'kamu', 'aku', 'saya', 'kita', 'mereka', 'dia', 'beliau', 'anda', 'kalian',
    'kami', 'engkau', 'kau', 'sebuah', 'suatu', 'sang', 'si', 'para', 'kaum',
    'segala', 'seluruh', 'semua', 'setiap', 'masing', 'beberapa', 'sedikit',
    'banyak', 'adalah', 'ialah', 'merupakan', 'menjadi', 'bisa', 'dapat', 'mampu',
    'harus', 'wajib', 'perlu', 'hendak', 'akan', 'telah', 'sudah', 'pernah',
    'belum', 'masih', 'baru', 'hanya', 'cuma', 'sekadar', 'hampir', 'nyaris',
    'agak', 'cukup', 'terlalu', 'amat', 'sangat', 'benar', 'sungguh', 'ada',
    'tidak', 'bukan', 'jangan', 'usah', 'mohon', 'tolong', 'harap', 'silahkan',
    'mari', 'ayo', 'wah', 'aduh', 'astaga', 'ya', 'sebagai', 'bagi', 'menurut',
    'tentang', 'mengenai', 'oleh_karena', 'maka_dari', 'adapun', 'bahwa',
    'bahwasanya', 'sebab', 'andai', 'seandainya', 'seumpama', 'seakan',
    'seolah', 'ibarat', 'sebagaimana', 'seperti', 'bagai', 'laksana', 'daripada',
    'alih', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan',
    'sembilan', 'sepuluh', 'seratus', 'seribu', 'sejuta', 'pertama', 'kedua',
    'ketiga', 'keempat', 'kelima'
}
PRIORITY_CATEGORIES = {
    "Bokep Viral": "Bokep Viral",
    "Bokep Pelajar": "Bokep Pelajar",
    "Video Ngentot": "Video Ngentot",
    "Bokep Perawan": "Bokep Perawan",
    "Jilbab Mesum": "Jilbab Mesum",
    "Prank Ojol": "Prank Ojol",
    "Pijat Plus": "Pijat Plus",
    "Sepong Kontol": "Sepong Kontol",
    "Hijab Tobrut": "Hijab Tobrut",
    "Tante Sange": "Tante Sange",
    "Abg Viral": "Keponakan",
    "Skandal Mesum": "Skandal Mesum",
    "Cewek Colmek": "Cewek Colmek",
    "Syakirah": "Syakirah",
    "Doggy Style": "Doggy Style",
    "Tante Bohay": "Tante Bohay",
    "Cewek Semok": "Cewek Semok",
    "Msbreewc": "Msbreewc",
    "Cewek Tobrut": "Cewek Tobrut",
    "Janda Sange": "Janda Sange",
    "Bokep Jepang": "Bokep Jepang",
    "Bokepsatset": "Bokepsatset",
    "Bebasindo": "Bebasindo",
    "Doodstream": "Doodstream",
    "Doods Pro": "Tiktokers",
    "Skandal": "Selingkuh",
    "Cantik Tobrut": "Cantik Tobrut",
    "Memeksiana": "Memeksiana",
    "Susu Gede": "Susu Gede",
    "Adik Kakak": "Adik Kakak",
    "Simontok": "Simontok",
    "Bokep Indo": "Bokep Indo",
    "Bokep Stw": "Bokep Stw",
    "Video Lokal": "Video Lokal",
    # === TAMBAHAN BARU (Title Case) ===
    "Bokep Indo": "Bokep Indo",
    "Bokep Smp": "Bokep Smp",
    "Bokep Sma": "Bokep Sma",
    "Bokep Abg": "Bokep Abg",
    "Bokep Jilbab": "Bokep Jilbab",
    "Bokep Hijab": "Bokep Hijab",
    "Bokep China": "Bokep China",
    "Bokep Cina": "Bokep Cina",
    "Bokep Colmek": "Bokep Colmek",
    "Bokep Tante": "Bokep Tante",
    "Bokep Live": "Bokep Live",
    "Jav Sub Indo": "Jav Sub Indo",
    "Bokep Jepang": "Bokep Jepang",
    "Bokep Barat": "Bokep Barat",
    "Jav": "Jav",
    "Bokep Jav": "Bokep Jav",
    "Bokep Bispak": "Bokep Bispak",
    "Bokep Ngentot": "Bokep Ngentot",
    "Bokep Ngewe": "Bokep Ngewe",
    "Bokep Mahasiswi": "Bokep Mahasiswi",
    "Bokep Cam": "Bokep Cam",
    "Bokep Masturbasi": "Bokep Masturbasi",
    "Bokep Ukhti": "Bokep Ukhti",
    "Bokep Tobrut": "Bokep Tobrut",
    "Bokep Gangbang": "Bokep Gangbang",
    "Bokep Scandal": "Bokep Scandal",
    "Bokep Skandal": "Bokep Skandal",
    "Bokep Ngintip": "Bokep Ngintip",
    "Bokepsin": "Bokepsin",
    "Xpanas": "Xpanas",
    "Bokepindoh": "Bokepindoh",
    "Indo18": "Indo18",
    "Avtub": "Avtub",
    "Bokep Sepong": "Bokep Sepong",
    "Bokepcrot": "Bokepcrot",
    "Bokep Bacol": "Bokep Bacol",
    "Bokep Vcs": "Bokep Vcs",
    "Bokep Terbaru": "Bokep Terbaru",
    "Bokep Mesum": "Bokep Mesum",
    "Sebokep": "Sebokep",
    "Playbokep": "Playbokep",
    "Bokep Terlengkap": "Bokep Terlengkap",
    "Drbokep": "Drbokep",
    "Bokep Hot": "Bokep Hot",
    "Bokep Cantik": "Bokep Cantik",
    "Bokep TikTok": "Bokep TikTok",
    "King Bokep": "King Bokep"
}
# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================
def get_shard_hex(key: str) -> str:
    hash_bytes = hashlib.sha256(key.encode()).digest()
    return f"{hash_bytes[0]:02x}"
# ============================================================================
# DATA NORMALIZER - VERSI DIPERBAIKI
# ============================================================================
class DataNormalizer:
    def __init__(self):
        self.random_words = RANDOM_WORDS
        self.stop_words = STOP_WORDS
    def apply_word_replacements(self, title: str) -> str:
        if not title:
            return title
        text = title.lower()
        for old, new in WORD_REPLACEMENTS.items():
            text = text.replace(old, new)
        return text
    def _generate_random_title(self) -> str:
        num_words = random.randint(4, 8)
        selected = random.sample(self.random_words, min(num_words, len(self.random_words)))
        random.shuffle(selected)
        return ' '.join(selected)
    def clean_and_format_title(self, title: str) -> str:
        """
        Membersihkan judul dari angka tidak berguna,
        mempertahankan tahun 2024-2026, 'part X', dan angka yang menyatu dengan kata.
        Kemudian mengubah menjadi Title Case (setiap kata huruf pertama kapital).
        """
        if not title or not title.strip():
            return self._generate_random_title()
        text = str(title).strip()
        # 1. Pisahkan camelCase dan kata yang menempel
        text = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', text)
        text = re.sub(r'([A-Z]{2,})([A-Z][a-z])', r'\1 \2', text)
        # 2. Fungsi untuk menentukan apakah angka boleh dipertahankan
        def keep_number(match: re.Match) -> str:
            num = match.group(0)
           
            # Pertahankan tahun 2024 - 2026
            if re.fullmatch(r'202[4-6]', num):
                return num
           
            # Pertahankan angka setelah kata "part" (part 27, Part 5, dll)
            context_before = text[max(0, match.start() - 40):match.start()].lower()
            if 'part' in context_before:
                return num
           
            # Pertahankan angka yang menyatu dengan huruf (Kissmee78, Xpanas99, Telegram123, dll)
            nearby = text[max(0, match.start() - 10):match.end() + 10]
            if re.search(r'[a-zA-Z]\d|\d[a-zA-Z]', nearby):
                return num
           
            # Hapus angka lainnya (VID, tanggal panjang, kode random, jam, dll)
            return ''
        # 3. Hapus angka yang tidak diinginkan
        text = re.sub(r'\b\d+\b', keep_number, text)
        # 4. Bersihkan karakter non-alfanumerik dan spasi berlebih
        text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        # 5. Jika judul terlalu pendek atau kosong setelah dibersihkan
        if not text or len(text.split()) < 2:
            return self._generate_random_title()
        # 6. Ubah menjadi Title Case (Huruf pertama setiap kata kapital)
        words = text.split()
        title_case_words = []
       
        for word in words:
            word_lower = word.lower()
            if word_lower == 'part':
                title_case_words.append('Part') # "Part" tetap kapital
            elif word_lower in self.stop_words:
                title_case_words.append(word_lower) # stop words tetap kecil
            else:
                title_case_words.append(word.capitalize())
        clean_title = ' '.join(title_case_words)
        # 7. Hapus duplikasi kata berurutan (contoh: Video Video → Video)
        clean_title = re.sub(r'\b(\w+)\s+\1\b', r'\1', clean_title, flags=re.IGNORECASE)
        return clean_title
    def is_valid_word(self, word: str) -> bool:
        if not word or len(word) < 2 or any(char.isdigit() for char in word):
            return False
        return word.lower() not in self.stop_words
    def generate_tags_from_title(self, title: str) -> List[str]:
        if not title or title.strip() == "":
            return ["Bokep Viral", "Video Terbaru", "Asupan HD", "Simontok"]
        words = title.split()
        base_tags = []
        seen = set()
        for word in words:
            clean_word = re.sub(r'[^a-zA-Z0-9]', '', word).strip()
            if not clean_word:
                continue
            lower_word = clean_word.lower()
            if (self.is_valid_word(clean_word) and
                lower_word not in seen and
                len(clean_word) >= 2):
               
                base_tags.append(clean_word.title())
                seen.add(lower_word)
                if len(base_tags) >= 8:
                    break
        if len(base_tags) < 3:
            needed = 3 - len(base_tags)
            for rw in random.sample(self.random_words, min(needed, len(self.random_words))):
                if rw.lower() not in seen:
                    base_tags.append(rw)
                    seen.add(rw.lower())
        prefixes = ['Bokep', 'Video', 'Full Album', 'Streaming', 'Simontok', 'Asupan', 'Vidio', 'Yandex', 'Twitter']
        final_tags = []
        used_prefixes = set()
        used_combinations = set()
        random.shuffle(base_tags)
        for base in base_tags:
            if len(final_tags) >= 6:
                break
            available = [p for p in prefixes if p not in used_prefixes]
            if not available:
                break
            prefix = random.choice(available)
            tag = f"{prefix} {base}"
            if tag not in used_combinations:
                final_tags.append(tag)
                used_combinations.add(tag)
                used_prefixes.add(prefix)
        while len(final_tags) < 4 and used_prefixes:
            available = [p for p in prefixes if p not in used_prefixes]
            if not available:
                break
            prefix = random.choice(available)
            base = random.choice(base_tags) if base_tags else "Terbaru"
            tag = f"{prefix} {base}"
            if tag not in used_combinations:
                final_tags.append(tag)
                used_combinations.add(tag)
                used_prefixes.add(prefix)
        return final_tags[:6]
    def get_kategori(self, title: str) -> str:
        if not title:
            return "Video Viral"
        text_lower = title.lower()
        for key, value in PRIORITY_CATEGORIES.items():
            if key in text_lower:
                return value
        words = title.split()
        return f"{words[0]} {words[1]}" if len(words) >= 2 else (words[0] if words else "Video Viral")
    def generate_fld_id(self, kategori: str) -> str:
        if not kategori:
            return "video-viral"
        slug = re.sub(r'[^a-z0-9\s-]', '', kategori.lower())
        slug = re.sub(r'\s+', '-', slug.strip())
        slug = re.sub(r'-+', '-', slug)
        return slug
    def parse_duration(self, duration) -> int:
        if isinstance(duration, (int, float)):
            return int(duration)
        if isinstance(duration, str):
            try:
                parts = list(map(int, reversed(duration.split(':'))))
                return sum(p * (60 ** i) for i, p in enumerate(parts))
            except:
                return 0
        return 0
    def duration_to_size(self, duration_seconds: int) -> int:
        if duration_seconds <= 0:
            return 50 * 1024 * 1024
        bitrate_kbps = 2000 if duration_seconds < 300 else 2800 if duration_seconds < 900 else 3500
        bytes_size = int(duration_seconds * bitrate_kbps * 125)
        return max(bytes_size, 10 * 1024 * 1024)
    def normalize_data(self, api_data: Dict, source: str, existing_map: Dict) -> List[Dict]:
        normalized = []
        files = api_data.get('result', {}).get('files', [])
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
       
        for item in files:
            filecode = item.get('file_code') or item.get('filecode', '')
            if not filecode:
                continue
            raw_title = item.get('title') or item.get('file_title', 'Video Tanpa Judul')
           
            existing = existing_map.get(filecode)
            if existing and existing.get('title'):
                clean_title = existing['title']
                kategori = existing.get('kategori', 'Video Viral')
                tag = existing.get('tag', [])
            else:
                clean_title = self.clean_and_format_title(raw_title)
                kategori = self.get_kategori(clean_title)
                tag = self.generate_tags_from_title(clean_title)
            fld_id = self.generate_fld_id(kategori)
            duration_sec = self.parse_duration(item.get('length') or item.get('file_length', 0))
            api_size = item.get('size') or item.get('file_size')
            size_bytes = int(api_size) if api_size and str(api_size).isdigit() else self.duration_to_size(duration_sec)
            base = {
                'filecode': filecode,
                'file_code': filecode,
                'title': clean_title,
                'kategori': kategori,
                'tag': tag,
                'public': "1",
                'fld_id': fld_id,
                'length': duration_sec,
                'size': size_bytes,
                'views': item.get('views') or item.get('file_views', 0),
                'uploaded': item.get('uploaded', ''),
                'last_view': current_time,
                'api_source': source,
                'canplay': "1",
            }
            if source == 'doodstream':
                base.update({
                    'protected_embed': f'https://dodl.pages.dev/{filecode}',
                    'protected_dl': f'https://doodstream.com/d/{filecode}',
                    'single_img': item.get('single_img') or item.get('splash_img', ''),
                    'splash_img': item.get('splash_img') or '',
                })
            else:
                base.update({
                    'protected_embed': f'https://luvluv.pages.dev/{filecode}',
                    'protected_dl': f'https://lulustream.com/d/{filecode}',
                    'single_img': item.get('player_img', f'https://img.lulucdn.com/{filecode}_t.jpg'),
                    'splash_img': item.get('player_img', f'https://img.lulucdn.com/{filecode}_xt.jpg'),
                })
            normalized.append(base)
        return normalized
# ============================================================================
# ASYNC API CLIENT - OPTIMIZED + RANDOM USER AGENT
# ============================================================================
class AsyncAPIClient:
    def __init__(self):
        self.normalizer = DataNormalizer()
        self.session = None
        self.connector = None
    async def __aenter__(self):
        self.connector = aiohttp.TCPConnector(
            limit=120,
            limit_per_host=25,
            ttl_dns_cache=300,
            keepalive_timeout=30,
            ssl=False
        )
        timeout = aiohttp.ClientTimeout(total=60, connect=15, sock_read=45)
        self.session = aiohttp.ClientSession(
            connector=self.connector,
            timeout=timeout,
        )
        return self
    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()
        if self.connector:
            await self.connector.close()
    async def fetch_page(self, url: str, max_retries: int = 5):
        for attempt in range(max_retries):
            try:
                headers = {"User-Agent": get_random_user_agent()}
               
                async with self.session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        return await resp.json()
                    elif resp.status == 429:
                        delay = (attempt + 1) * 2.5 + random.uniform(0.5, 1.5)
                        logger.warning(f"Rate limit 429 dari {url}, delay {delay:.1f}s")
                        await asyncio.sleep(delay)
                    else:
                        await asyncio.sleep(1)
            except asyncio.TimeoutError:
                logger.warning(f"Timeout pada {url}")
            except Exception as e:
                logger.warning(f"Error fetch {url}: {type(e).__name__}")
           
            await asyncio.sleep(2 ** attempt * 0.6 + random.uniform(0, 0.8))
        return None
    async def fetch_all_pages_concurrent(self, config: Dict, source: str, existing_map: Dict) -> List[Dict]:
        all_videos = []
        page = 1
        semaphore = asyncio.Semaphore(config['concurrent_requests'])
        async def fetch_task(p: int):
            async with semaphore:
                url = f"{config['api_url']}?key={config['api_key']}&per_page={config['per_page']}&page={p}"
                data = await self.fetch_page(url, config['max_retries'])
                if data and data.get('status') == 200:
                    result = self.normalizer.normalize_data(data, source, existing_map)
                    await asyncio.sleep(config['request_delay'] + random.uniform(0.05, 0.25))
                    return result
                return []
        logger.info(f"🌐 Fetching dari {source} (concurrent: {config['concurrent_requests']})...")
        while True:
            tasks = [fetch_task(page + i) for i in range(config['concurrent_requests'])]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            batch_added = sum(len(res) for res in results if isinstance(res, list))
            for res in results:
                if isinstance(res, list):
                    all_videos.extend(res)
            if batch_added == 0:
                break
            logger.info(f"[{source}] Halaman {page}+ → +{batch_added} video")
            page += config['concurrent_requests']
        logger.info(f"✅ {source} selesai: {len(all_videos)} video")
        return all_videos
# ============================================================================
# FILE OPERATIONS
# ============================================================================
def load_existing_videos_map() -> Dict:
    output_dir = Path('output')
    shard_base = output_dir / 'shard'
    if not shard_base.exists():
        return {}
    video_map = {}
    for shard_dir in shard_base.iterdir():
        if not shard_dir.is_dir(): continue
        for batch_file in shard_dir.glob('batch_*.json'):
            try:
                with open(batch_file, 'r', encoding='utf-8') as f:
                    batch_videos = json.load(f)
                    for v in batch_videos:
                        fc = v.get('filecode') or v.get('file_code')
                        if fc:
                            video_map[fc] = v
            except Exception as e:
                logger.warning(f"Gagal membaca {batch_file}: {e}")
    return video_map
def save_sharded_data(videos: List[Dict]):
    output_dir = Path('output')
    shard_base = output_dir / 'shard'
    shard_base.mkdir(exist_ok=True)
    shard_groups = {}
    filecode_to_shard = {}
    filecode_to_batch = {}
    for video in videos:
        filecode = video.get('filecode') or video.get('file_code')
        if not filecode: continue
        shard_hex = get_shard_hex(filecode)
        shard_groups.setdefault(shard_hex, []).append(video)
        filecode_to_shard[filecode] = shard_hex
    for shard_hex, shard_videos in shard_groups.items():
        shard_dir = shard_base / shard_hex
        shard_dir.mkdir(exist_ok=True)
        for f in shard_dir.glob('batch_*.json'):
            f.unlink()
        batch_count = (len(shard_videos) + SHARD_BATCH_SIZE - 1) // SHARD_BATCH_SIZE
        for batch_idx in range(batch_count):
            start = batch_idx * SHARD_BATCH_SIZE
            end = start + SHARD_BATCH_SIZE
            batch_videos = shard_videos[start:end]
            batch_file = shard_dir / f'batch_{batch_idx}.json'
            with open(batch_file, 'w', encoding='utf-8') as f:
                json.dump(batch_videos, f, ensure_ascii=False, indent=2)
            for video in batch_videos:
                fc = video.get('filecode') or video.get('file_code')
                if fc:
                    filecode_to_batch[fc] = batch_idx
    metadata = {
        'total_videos': len(videos),
        'last_updated': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'shard_batch_size': SHARD_BATCH_SIZE,
        'shard_count': len(shard_groups),
        'filecode_to_shard': filecode_to_shard,
        'filecode_to_batch': filecode_to_batch,
        'shard_groups_summary': {sh: len(videos) for sh, videos in shard_groups.items()}
    }
    with open(output_dir / 'shard_metadata.json', 'w', encoding='utf-8') as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    logger.info(f"💾 Data disimpan dalam {len(shard_groups)} shard, total {len(videos)} video")
# ============================================================================
# MODIFIED: build_title_index with natural formatting for short titles
# ============================================================================
def build_title_index(videos: List[Dict], output_dir: Path):
    title_index = {}
    skipped = 0
    fallback_count = 0
   
    # Track jumlah duplikasi per judul
    title_counter = {}
   
    def enrich_title(base_title: str, random_word: str = None) -> str:
        """Menambahkan random word ke judul dengan format natural."""
        if random_word is None:
            random_word = random.choice(RANDOM_WORDS)
        format_variation = random.choice([
            f"{random_word} • {base_title}",
            f"{base_title} Versi {random_word}",
            f"{base_title} {random_word}",
            f"{random_word} - {base_title}",
            f"{base_title} + {random_word}",
            f"{random_word} | {base_title}",
        ])
        return format_variation
   
    for video in videos:
        filecode = video.get('filecode') or video.get('file_code')
        if not filecode:
            skipped += 1
            continue
        title = video.get('title', '').strip()
        if not title:
            title = f"Video {filecode[-8:]}"
            fallback_count += 1
       
        base_title = title
        word_count = len(base_title.split())
       
        # Cek apakah judul sudah ada sebelumnya
        if base_title in title_counter:
            # Duplikat: tambahkan random word
            title_counter[base_title] += 1
            duplicate_count = title_counter[base_title]
           
            random_word = random.choice(RANDOM_WORDS)
            title = enrich_title(base_title, random_word)
           
            # Jika masih bentrok (sangat kecil kemungkinannya)
            if title in title_index:
                title = f"{base_title} #{duplicate_count}"
        else:
            title_counter[base_title] = 1
            # Jika judul unik dan kurang dari 5 kata, perkuat dengan random word
            if word_count < 5:
                random_word = random.choice(RANDOM_WORDS)
                enriched = enrich_title(base_title, random_word)
                # Pastikan enriched title belum ada di index (hampir pasti belum)
                if enriched not in title_index:
                    title = enriched
                # Jika bentrok, kita tetap gunakan base_title (tidak perlu fallback karena unik)
       
        shard_hex = get_shard_hex(filecode)
        title_index[title] = {
            'filecode': filecode,
            'shard_hex': shard_hex
        }
   
    with open(output_dir / 'title_index.json', 'w', encoding='utf-8') as f:
        json.dump(title_index, f, ensure_ascii=False, indent=2)
   
    logger.info(f"🔍 Indeks judul dibuat: {len(title_index)} entri (fallback: {fallback_count})")
# ============================================================================
# MAIN
# ============================================================================
async def main():
    start_time = datetime.now()
    logger.info("=" * 80)
    logger.info(f"🚀 MEMULAI FETCH DATA VIDEO - Async Optimized {'+ uvloop' if UVLOOP_ENABLED else ''} + Random UA")
    logger.info("=" * 80)
    try:
        existing_map = load_existing_videos_map()
        logger.info(f"📂 Loaded {len(existing_map)} video existing dari shard")
        all_videos = []
        async with AsyncAPIClient() as client:
            for source_name, config in CONFIGS.items():
                videos = await client.fetch_all_pages_concurrent(config, source_name, existing_map)
                all_videos.extend(videos)
        # Deduplikasi
        seen = set()
        unique_videos = [v for v in all_videos if (fc := v.get('filecode') or v.get('file_code')) and fc not in seen and not seen.add(fc)]
        unique_videos.sort(key=lambda x: x.get('uploaded', ''), reverse=True)
        save_sharded_data(unique_videos)
        output_dir = Path('output')
        build_title_index(unique_videos, output_dir)
        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"🎉 SELESAI! Total: {len(unique_videos)} video | Waktu: {duration:.1f} detik")
        result = {
            'status': 'completed',
            'total_videos': len(unique_videos),
            'total_pages': (len(unique_videos) + SHARD_BATCH_SIZE - 1) // SHARD_BATCH_SIZE,
            'execution_time_seconds': round(duration, 2),
            'last_updated': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        with open('fetch_status.json', 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print("\n===JSON_RESULT_START===")
        print(json.dumps(result, ensure_ascii=False))
        print("===JSON_RESULT_END===")
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        result = {'status': 'error', 'error': str(e)}
        print("\n===JSON_RESULT_START===")
        print(json.dumps(result, ensure_ascii=False))
        print("===JSON_RESULT_END===")
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("⏹️ Proses dihentikan")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1) 