import { CONFIG, IMG_ERR } from '../../lib/config.js';
import { Header } from '../components/header.js';
import { Footer } from '../components/footer.js';
import { MobileMenu } from '../components/mobile-menu.js';
import { SearchModal } from '../components/search-modal.js';
import { Styles } from '../components/styles.js';

export function BaseLayout(t, b, schema, url, meta = {}) {
    const canonical = meta.canonical || url.href;
    const description = meta.description || `Situs streaming video viral dan terbaru terlengkap. Nonton video HD gratis hanya di ${CONFIG.name}.`;
    const image = meta.image || CONFIG.logo;
    const keywords = meta.keywords || "video viral, streaming video, video lucu, hiburan, konten viral 2024";
    const siteTitle = `${t} - ${CONFIG.name}`;

    const style = Styles();
    const script = getScript();

    // Pagination prev/next link tags for SEO
    const paginationLinks = (meta.prevUrl ? `<link rel="prev" href="${meta.prevUrl}">` : '') +
                            (meta.nextUrl ? `<link rel="next" href="${meta.nextUrl}">` : '');

    return `<!doctype html><html lang="id" class="dark"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#0a0a0a">
    <title>${siteTitle}</title>
    <meta name="description" content="${description}">
    <meta name="keywords" content="${keywords}">
    <meta name="robots" content="${meta.robots || "index, follow"}">
    <link rel="canonical" href="${canonical}">
    ${paginationLinks}
    <link rel="icon" type="image/png" sizes="32x32" href="/images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/images/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png">
    <link rel="shortcut icon" href="/images/favicon.ico">
    
    <meta property="og:locale" content="id_ID">
    <meta property="og:site_name" content="${CONFIG.name}">
    <meta property="og:title" content="${siteTitle}">
    <meta property="og:description" content="${description}">
    <meta property="og:url" content="${canonical}">
    <meta property="og:image" content="${image}">
    <meta property="og:image:width" content="1280">
    <meta property="og:image:height" content="720">
    <meta property="og:type" content="${meta.type || "website"}">
    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="${siteTitle}">
    <meta name="twitter:description" content="${description}">
    <meta name="twitter:image" content="${image}">

    <script type="application/ld+json">
    ${JSON.stringify({
        "@context": "https://schema.org",
        "@type": "WebSite",
        "@id": `${url.origin}/#website`,
        "name": CONFIG.name,
        "url": url.origin,
        "description": CONFIG.description,
        "potentialAction": {
            "@type": "SearchAction",
            "target": `${url.origin}/?q={search_term_string}`,
            "query-input": "required name=search_term_string"
        }
    })}
    </script>
    <script type="application/ld+json">
    ${JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Organization",
        "@id": `${url.origin}/#organization`,
        "name": CONFIG.name,
        "url": url.origin,
        "logo": url.origin + CONFIG.logo
    })}
    </script>
    ${schema ? `<script type="application/ld+json">${JSON.stringify(schema)}</script>` : ""}
    
    <link rel="preconnect" href="https://i0.wp.com" crossorigin>
    <link rel="dns-prefetch" href="https://i0.wp.com">

    <style>${style}</style>
    </head><body>
    <a href="#mainContent" class="skip-nav" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;z-index:9999;padding:8px 16px;background:hsl(var(--primary));color:#fff;text-decoration:none;&:focus{position:fixed;left:16px;top:16px;width:auto;height:auto;overflow:visible;}">Langsung ke Konten</a>
    ${MobileMenu()}
    ${Header(url.origin)}
 
    <main class="container" role="main" id="mainContent">${b}</main>

    ${SearchModal()}
    ${Footer()}

    <script>${script}</script> 

 <!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4258060,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4258060&101" alt="${CONFIG.name} stats" border="0"></a></noscript>
<!-- Histats.com  END  -->
 <aside id="ad-container" class="ad-container" style="display: none;" aria-label="Iklan">
    <button class="close-btn" onclick="closeAd()" aria-label="Tutup iklan">×</button>
     <script async data-cfasync="false" data-clbaid="" src="//bartererfaxtingling.com/bn.js"></script>
<div data-cl-spot="2064816"></div>
</aside>

<script data-cfasync="false">!function(){"use strict";for(var n=decodeURI("wd%60andp%5EjZd%5CZZQP_%5DQYUNURVWGLIECONDPP?MCIL:BI;%3C65?%3C/6:0%3Eq%3C,3-%25160-+-%7D%20%20%7Dyyut#t%20v$v!ryz!nQ%7BkrvhrmabcAkh%5Bbfkjaie%5EUbPZYUY%5D%5DIUIJ%5EIIQOOSMP%3CAS%3E%3E9D886=3;=05/-5*(/)'/+1)#%7C%20(yzzvzzv)yp%25x%7Brkj%7Cltfeffggvonih%5D%5C%5Bcba%5CZk%5BSRcW_dPSa%60MN%5DLWKMJITWOJAAKKK:=v?vCB%3E@@o8%22+;604,C2$+%25%222#1)%7C-!\u0026$CBQTedSPj33H76o4EEEEEEEEEEEEEEEEEEEEEEEEEEKKKKKKKKKKKKKKKKKKKKKKKKKK__________3\u0026%3Cv16#'m,%25).,T%3C~xPO9ls96I3ej5%2262=1/%5E+($%3CX)%22%5Cgdr%5Eb%7BN%20%7CC%5DbOS/_MUZTRWQVCGQQ=MN8H:7A@@#10@@0AnA10.:,3.862%227-%7Co!'~'!,#s%5CVVoasp%7B%7Dnnzfekrvesedlmh%5Cn_gickYaV%60bR%5DY%5B%5D.NX%5BNTVLGOT@@RFKIa0AEhf%5COYIgdVISw+,p5:*0Kb10+#%7B0%20--vux!ttuv%22%22%22~txptvifpVvpr%60ebdonik1%25$WYSdi%5DQTQ_%3ERUL%60TRH1GFRCQ@@%3CN:d23ut!%25vOZCA2Wa/)39*").replace(/((\\x40){2})/g,"$2").split("").map(((n,t)=>{const r=n.charCodeAt(0)-32;return r>=0&&r<95?String.fromCharCode(32+(r+t)%95):n})).join(""),t=[0,9,16,23,29,35,41,47,53,59,65,71,75,79,80,81,91,104,107,110,112,115,123,126,131,134,141,143,149,155,161,174,178,180,181,187,188,190,192,194,197,200,204,208,213,219,226,234,241,250,251,251,257,265,267,268,273,275,279,280,281,343,357,358,359,362,368,384,396,397,407,419,421,426,429,431,437,441,446,468,469,472,478,486,492,502,513,537,542,549,556,562,574,582,589,606,611,612,613,619,620,625,630],r=0;r<t.length-1;r++)t[r]=n.substring(t[r],t[r+1]);var o=[t[0],t[1],t[2],t[3],t[4],t[5],t[6],t[7],t[8],t[9],t[10]];o.push(o[1]+t[11]);var e=window,s=e.Math,i=e.Error,c=e.RegExp,u=e.document,l=e.navigator,h=e.Uint8Array;r=[t[12],o[7],t[13]+o[8],t[14]+o[8],t[15],t[16],t[17],t[18],t[19],t[20],t[21]];const a=t[22]+o[10],f={2:a+t[23],15:a+t[23],9:a+o[4],16:a+o[4],10:a+o[3],17:a+o[3],19:a+t[24],20:a+t[24],21:a+t[24]},E=t[25]+o[10],d={2:o[2],15:o[2],9:o[4],16:o[4],10:o[3],17:o[3],5:t[26],7:t[26],19:t[24],20:t[24],21:t[24]},v={15:t[27],16:t[28],17:t[29],19:o[6],20:o[6],21:o[6]},K=t[30],C=K+t[31],w=K+o[7],p=t[32]+o[1]+t[33],g=t[34],B=g+(o[1]+t[35]),_=g+o[11],D=g+(o[11]+t[36]),I=[t[37],t[38],t[39],t[40],t[41],t[42],t[43],t[44],t[45],t[46]],S={0:t[47],1:t[48]};class y extends i{constructor(n,o=0,s){super(n+(s?t[49]+s:t[50])),this[r[0]]=S[o],e.Object.setPrototypeOf(this,y.prototype)}}function P(n,r,o){try{return t[51],n()}catch(n){if(r)return r(n)}}const Q=n=>{const[o]=n.split(t[53]);let[e,s,i]=((n,t)=>{let[r,o,...e]=n.split(t);return o=[o,...e].join(t),[r,o,!!e.length]})(n,t[54]);i&&P((()=>{throw new y(t[55])}),typeof handleException===t[52]?n=>{null===handleException||void 0===handleException||handleException(n)}:undefined);const u=new c(t[56]+o+t[57],t[58]),[l,...h]=e.replace(u,t[50]).split(t[59]);return{protocol:o,origin:e,[r[1]]:l,path:h.join(t[59]),search:s}},b=t[60],x=[[97,122],[65,90],[48,57]],A=t[61],N=(n,t)=>s.floor(s.random()*(t-n+1))+n;function O(n){let r=t[50];for(let t=0;t<n;t++)r+=b.charAt(s.floor(s.random()*b.length));return r}const R=()=>{const n=I[N(0,I.length-1)],r=N(0,1)?N(1,999999):(n=>{let r=t[50];for(let t=0;t<n;t++)r+=e.String.fromCharCode(N(97,122));return r})(N(2,6));return n+t[62]+r},V=(n,r)=>(null==n?void 0:n.length)?n.split(t[63]).map((n=>{const o=n.indexOf(t[62])+1,e=n.slice(0,o),s=n.slice(o);return e+r(s)})).join(t[63]):t[50],k=(n,r)=>{const{search:o,origin:i}=Q(n),c=o?o.split(t[63]):[],[u,l]=((n,t)=>{const r=[],o=[];return n.forEach((n=>{n.indexOf(t)>-1?o.push(n):r.push(n)})),[r,o]})(c,K);if(!u.length)return n;const h=((n,t)=>{const r=[],o=N(n,t);for(let n=0;n<o;n++)r.push(R());return r})(...c.length>4?[0,2]:[5,9]),a=t[64]+r;u.indexOf(a)<0&&u.push(a);const f=(n=>{const t=[...n];let r=t.length;for(;0!==r;){const n=s.floor(s.random()*r);r--;[t[r],t[n]]=[t[n],t[r]]}return t})([...u,...h]);let E=((n,r)=>{const o=(n=>{let t=n%71387;return()=>t=(23251*t+12345)%71387})((n=>n.split(t[50]).reduce(((n,t)=>31*n+t.charCodeAt(0)&33554431),19))(n)),s=(i=r,V(i,e.decodeURIComponent)).split(t[50]).map((n=>((n,t)=>{const r=n.charCodeAt(0);for(const n of x){const[o,s]=n;if(r>=o&&r<=s){const n=s-o+1,i=o+(r-o+t())%n;return e.String.fromCharCode(i)}}return n})(n,o))).join(t[50]);var i;return n+t[63]+(n=>V(n,e.encodeURIComponent))(s)})(O(N(2,6))+t[62]+O(N(2,6)),f.join(t[63]));return l.length>0&&(E+=t[63]+l.join(t[63])),i+t[54]+E},m=()=>{const n=new c(C+t[65]).exec(e.location.href),r=n?+n[1]:null;return null!=r?r:e.Date.now()},M=new c(t[67]);function T(n){const r=function(){const n=new c(w+t[66]).exec(e.location.href);return n&&n[1]?n[1]:null}();return r?n.replace(M,t[68]+r+t[59]):n}function U(){if(l){const n=/Mac/.test(l.userAgent)&&l[A]>2,t=/iPhone|iPad|iPod/.test(l.userAgent);return n||t}return!1}function z(){return l&&/android/i.test(l.userAgent)}const W=o[0];function Y(){return t[71]+o[9]in e||t[72]+o[9]in e||t[73]+o[9]+t[74]in e||P((()=>!!(e[W]||l[W]||u.documentElement.getAttribute(W))),(()=>!1))||t[75]in e||t[76]in e||t[77]in e||t[78]in e||t[32]+o[0]+t[79]+o[5]+t[80]in u||(U()||z())&&l&&/Mobi/i.test(l.userAgent)&&!function(){try{return u.createEvent(t[69]),t[70]in u.documentElement}catch(n){return!1}}()||function(){var n;const r=t[81],o=t[82],s=t[83],i=t[84],u=t[85];let h=!1;var a,f;return l&&e[r]&&(z()||U())&&(h=l[A]<2&&new c(t[86]).test(l[o]),U()&&(h=h&&(a=null!==(n=l[s])&&void 0!==n?n:t[50],f=t[87],!(a.indexOf(f)>-1))&&e[r][i]<32&&!!e[r][u])),h}()}const Z=t[89];function $(){if((n=>{const[o]=(n=>{let o;try{if(o=e[n],!o)return[!1,o];const s=t[32]+n+t[88];return o[r[2]](s,s),o[r[3]](s)!==s?[!1,o]:(o[r[4]](s),[!0])}catch(n){return[!1,o,n]}})(n);return o})(t[91]))try{const n=localStorage[r[3]](Z);return[n?e.JSON.parse(n):null,!1]}catch(n){return[null,!0]}return[null,!0]}function j(n,r,o){let e=(/https?:\\/\\//.test(n)?t[50]:t[92])+n;return r&&(e+=t[59]+r),o&&(e+=t[54]+o),e}const L=(()=>{var n;const[o,s]=$();if(!s){const s=null!==(n=function(n){if(!n)return null;const r={};return e.Object.keys(n).forEach((o=>{const s=n[o];(function(n){const r=null==n?void 0:n[0],o=null==n?void 0:n[1];return typeof r===t[90]&&e.isFinite(+o)&&o>e.Date.now()})(s)&&(r[o]=s)})),r}(o))&&void 0!==n?n:{};localStorage[r[2]](Z,e.JSON.stringify(s))}return{get:n=>{const[t]=$();return null==t?void 0:t[n]},set:(n,t,o)=>{const i=[t,e.Date.now()+1e3*o],[c]=$(),u=null!=c?c:{};u[n]=i,s||localStorage[r[2]](Z,e.JSON.stringify(u))}}})(),G=(H=L,(n,t)=>{const{[r[1]]:o,path:e,search:s}=Q(n),i=H.get(o);if(i)return[j(i[0],e,s),!1];if((null==t?void 0:t[r[5]])&&(null==t?void 0:t[r[6]])){const{[r[1]]:n}=Q(null==t?void 0:t[r[5]]);return n!==o&&H.set(o,t[r[5]],t[r[6]]),[j(t[r[5]],e,s),!0]}return[n,!1]});var H;const J=[1,3,6,5,8,9,10,11,12,13,14,18,22],F=t[93],X=t[94];class q{constructor(n,t,o){this.t=n,this.o=t,this.i=o,this.u=u.currentScript,this.l=n=>this.h.then((t=>t&&t[r[7]](this.v(n)))),this.K=n=>h.from(e.atob(n),(n=>n.charCodeAt(0))),this.C=n=>0!=+n,this.h=this.p(),this[r[8]]=this.B(),e[p]=this[r[8]],e[D]=k}in(n){!this.C(n)||e[E+d[n]]||e[f[n]]||this._(n)}_(n){this.l(n).then((r=>{e[_+d[n]]=this.o;const s=this.D(),c=v[n],l=G(T(r))[0];if(c){const r=t[95]+c,e=u.querySelector(o[5]+t[96]+r+t[97]);if(!e)throw new i(t[98]+n);const l=e.getAttribute(r).trim();e.removeAttribute(r),s.setAttribute(r,l)}s.src=l,u.head.appendChild(s)}))}B(){return e[B]={},e.Promise[r[9]](J.map((n=>this.l(n).then((t=>{e[B][n]=t?T(t):void 0}))))).then((()=>!0))}v(n){const r=l?l.userAgent:t[50],o=e.location.hostname||t[50],s=e.innerHeight,i=e.innerWidth,c=sessionStorage?1:0,h=u.cookie?u.cookie.length:0,a=this.I(),f=Y()?1:0;return[s,i,c,m(),0,n,o.slice(0,100),h,a,r.slice(0,15),f].join(t[99])}I(){const n=(new e.Date)[X]();return!n||n>720||n<-720?0:720+n}p(){const n=e.WebAssembly&&e.WebAssembly.instantiate;return n?n(this.K(this.t),{}).then((({[r[10]]:n})=>{const{memory:o,[r[7]]:s}=n.exports,i=new e.TextEncoder,c=new e.TextDecoder(t[100]);return{[r[7]]:n=>{const t=i.encode(n),r=new h(o.buffer,0,t.length);r.set(t);const e=r.byteOffset+t.length,u=s(r,t.length,e),l=new h(o.buffer,e,u);return c.decode(l)}}})):e.Promise.resolve(null)}D(){const n=u.createElement(o[5]);return e.Object.assign(n.dataset,{[F]:t[101]},this.u?this.u.dataset:{}),n.async=!0,n}}const nn=(n,t,r,o)=>{const s=new q(n,t,r);e[o]=n=>s.in(n)};nn("AGFzbQEAAAABHAVgAAF/YAN/f38Bf2ADf39/AX5gAX8AYAF/AX8DCQgAAQIBAAMEAAQFAXABAQEFBgEBgAKAAgYJAX8BQdCIwAILB2cHBm1lbW9yeQIAA3VybAADGV9faW5kaXJlY3RfZnVuY3Rpb25fdGFibGUBABBfX2Vycm5vX2xvY2F0aW9uAAcJc3RhY2tTYXZlAAQMc3RhY2tSZXN0b3JlAAUKc3RhY2tBbGxvYwAGCuMICCEBAX9BwAhBwAgoAgBBE2xBoRxqQYfC1y9wIgA2AgAgAAuTAQEFfxAAIAEgAGtBAWpwIABqIgQEQEEAIQBBAyEBA0AgAUEDIABBA3AiBhshARAAIgVBFHBBkAhqLQAAIQMCfyAHQQAgBhtFBEBBACAFIAFwDQEaIAVBBnBBgwhqLQAAIQMLQQELIQcgACACaiADQbQILQAAazoAACABQQFrIQEgAEEBaiIAIARJDQALCyACIARqC3ECA38CfgJAIAFBAEwNAANAIARBAWohAyACIAUgACAEai0AAEEsRmoiBUYEQCABIANMDQIDQCAAIANqMAAAIgdCLFENAyAGQgp+IAd8QjB9IQYgA0EBaiIDIAFHDQALDAILIAMhBCABIANKDQALCyAGC5QGAgN+B38gACABQQMQAiEDIAAgAUEFEAIhBUGwCCgCACIGQQZsIQggBkEBdCIKQQRqIQkgACABQQgQAiEEIAZBMmoiByAHbEHoB2whByAAIAFBChACQgFRBEAgAyAGQQJqIAZBCGtuIAdsrX0hAwsgCCAJbCEBIAZBBGshCQJAIANCgMDiwsczWgRAQYCAgBBBgICACCAEIAGtgqcgCiAGQfn///8HamxuIgBBCUZBGHQgAEEDRhsgAEERRhtBACADIAetgCAJrYAiBELjggVSQRZ0IARCs4MFURtyIQBBASEKDAELQYCAgAIhAEEAIQogA0KAkIjarzN9Qv/3wL8XVg0AIAQgAa2CpyIBIAggBkEHa2wiCG4iC0F9cUEBRyEAIAtBBUYEfyABIAhBA25uIABqBSAAC0EXdEGAgIACciEAC0HACCADQbgIKQMAIgQgAyAEVBsgB62AIgQgBkEOaiILIAkgA0KAgPHtxzBUIgkbrYCnQQAgACADQoCQzKf2MVQiDBtyNgIAEAAaEAAaIAJC6OjRg7fOzpcvNwAAQQdBCkEIIANCgNDFl4MyVBsgA0KAlqKd5TBUIgYbQQtBDCAGGyACQQhqEAEhASMAQRBrIgAkACABQS46AAAgAEHj3rUDNgIEIABBgggtAAA6AAIgAEGACC8AADsBACAAIAA2AgwgACAAQQRqNgIIIAFBAWohB0EAIQEgAEEIaiAKQQJ0aigCACIKLQAAIggEQANAIAEgB2ogCDoAACAKIAFBAWoiAWotAAAiCA0ACwsgAEEQaiQAIAEgB2ohABAAGkHACCAEIAutgCAFQhuGQgBCgICAIEKAgIAwQoCAgAhCgICAGCAFQghRG0KAgIASQoCAwA0gA0KAiJfarDJUGyAMGyADQoCYxq7PMVQbIAYbIAkbhIQ+AgAQABpBAkEEQQUgA0KAkOqA0zJUIgEbEABBA3AiBhshB0EFQQggARshCEEAIQEDQCAAQS86AAAgASAGRiEJIAcgCCAAQQFqEAEhACABQQFqIQEgCUUNAAsgACACawsEACMACwYAIAAkAAsQACMAIABrQXBxIgAkACAACwUAQcQICwtJAgBBgAgLLmluAJ6ipqyytgAAAAAAAACfoKGjpKWnqKmqq62ur7Cxs7S1t21ucG9ycXRzdnUAQbAICw4KAAAAPQAAAP+/U+KeAQ==","13","1.1.32-st","ovvcgxb")}();</script>
<script data-cfasync="false" data-clocid="1867443" async src="//crittereasilyhangover.com/on.js" onerror="ovvcgxb(15)" onload="ovvcgxb(15)"></script>

</body></html>`;
}

function getScript() {
    return `
    function handleImageError(img) {
        img.removeAttribute('srcset');
        img.onerror = null;
        img.src = '${IMG_ERR}';
        img.classList.add('error-fallback');
    }

    document.addEventListener('error', function(e) {
        var target = e.target;
        if (target.tagName === 'IMG' && !target.dataset.fallbackApplied) {
            e.stopPropagation();
            target.dataset.fallbackApplied = "true";
            handleImageError(target);
        }
    }, true);

      
window.addEventListener('load', function() {
    var adContainer = document.getElementById('ad-container');
    var lastClosed = localStorage.getItem('adLastClosed');
    var now = new Date().getTime();

    // Cek apakah iklan sudah ditutup sebelumnya dan apakah 5 menit telah berlalu
    if (!lastClosed || (now - lastClosed) > 5 * 60 * 1000) {
        adContainer.style.display = 'block';
    }
});

function closeAd() {
    var adContainer = document.getElementById('ad-container');
    adContainer.style.display = 'none';

    // Simpan waktu penutupan iklan ke localStorage
    localStorage.setItem('adLastClosed', new Date().getTime());
}


    function initIcons(){if(typeof lucide!=='undefined'){lucide.createIcons()}}
function copyVideoUrl(){var url=window.location.href;navigator.clipboard.writeText(url).then(function(){alert('URL video berhasil disalin!')}).catch(function(){alert('Gagal menyalin URL')})}
function shareVideo(){if(navigator.share){navigator.share({title:document.title,text:document.querySelector('meta[name="description"]')?.content||'Nonton video viral di ${CONFIG.name}',url:window.location.href}).catch(function(){})}else{copyVideoUrl()}}
document.addEventListener('DOMContentLoaded',function(){var themeToggle=document.getElementById('themeToggle');var themeIcon=document.getElementById('themeIcon');var searchBtn=document.getElementById('searchBtn');var searchModal=document.getElementById('searchModal');var closeSearch=document.getElementById('closeSearch');var playTrigger=document.getElementById('playTrigger');var playerFrameContainer=document.getElementById('playerFrameContainer');var mainThumbnail=document.getElementById('mainThumbnail');var mainContent=document.getElementById('mainContent');var mobileMenuBtn=document.getElementById('mobileMenuBtn');var mobileMenu=document.getElementById('mobileMenu');var menuOverlay=document.getElementById('menuOverlay');var closeMobileMenu=document.getElementById('closeMobileMenu');function setTheme(theme){var root=document.documentElement;var icon=document.getElementById('themeIcon');if(theme==='light'){root.classList.add('light');root.classList.remove('dark');if(icon){icon.setAttribute('data-lucide','moon');icon.setAttribute('stroke','currentColor')}
localStorage.setItem('theme','light')}else{root.classList.remove('light');root.classList.add('dark');if(icon){icon.setAttribute('data-lucide','sun');icon.setAttribute('stroke','currentColor')}
localStorage.setItem('theme','dark')}
if(typeof lucide!=='undefined'){setTimeout(function(){lucide.createIcons()},10)}}
function toggleTheme(){var root=document.documentElement;var isLight=root.classList.contains('light');setTheme(isLight?'dark':'light')}
var savedTheme=localStorage.getItem('theme');if(savedTheme==='light'){setTheme('light')}else{setTheme('dark')}
if(themeToggle){themeToggle.addEventListener('click',function(e){e.preventDefault();toggleTheme()})}
function openMobileMenu(){if(mobileMenu)mobileMenu.classList.add('active');if(menuOverlay)menuOverlay.classList.add('active');document.body.classList.add('mobile-menu-open');if(mainContent)mainContent.classList.add('menu-open');}
function closeMobileMenuFunc(){if(mobileMenu)mobileMenu.classList.remove('active');if(menuOverlay)menuOverlay.classList.remove('active');document.body.classList.remove('mobile-menu-open');if(mainContent)mainContent.classList.remove('menu-open');}
if(mobileMenuBtn){mobileMenuBtn.addEventListener('click',function(e){e.stopPropagation();openMobileMenu()})}
if(closeMobileMenu){closeMobileMenu.addEventListener('click',function(e){e.stopPropagation();closeMobileMenuFunc()})}
if(menuOverlay){menuOverlay.addEventListener('click',function(){closeMobileMenuFunc()})}
window.addEventListener('resize',function(){if(window.innerWidth>=768){closeMobileMenuFunc()}});if(searchBtn){searchBtn.addEventListener('click',function(){if(searchModal)searchModal.classList.add('active');})}
if(closeSearch){closeSearch.addEventListener('click',function(){if(searchModal)searchModal.classList.remove('active');})}
if(searchModal){searchModal.addEventListener('click',function(e){if(e.target===searchModal)searchModal.classList.remove('active');})}
if(playTrigger&&playerFrameContainer&&mainThumbnail){playTrigger.addEventListener('click',function(){var videoUrl=playTrigger.getAttribute('data-video-url');playTrigger.style.display='none';mainThumbnail.style.display='none';playerFrameContainer.style.display='block';playerFrameContainer.innerHTML='<iframe src="'+videoUrl+'" frameborder="0" allow="autoplay; fullscreen" style="width:100%; height:100%;" title="Video Player - '+document.title+'" loading="lazy"></iframe>'})}
        initIcons();
    });

    `;
}
